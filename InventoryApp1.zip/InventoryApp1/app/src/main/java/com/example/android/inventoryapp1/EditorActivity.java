package com.example.android.inventoryapp1;

import android.app.ActionBar;
import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.widget.Toast;
import com.example.android.inventoryapp1.MeatDbHelper;

class EditorActivity {
    private ActionBar.Tab mProductEditText;
    private String priceInt;
    private ActionBar.Tab mQuantityEditText;
    private ActionBar.Tab mSupplierNameEditText;
    private ActionBar.Tab mSupplierPhoneEditText;


    /**
     * Get user input from editor and save new meats into database.
     */
    private void insertMeat() {
        // Read from input fields
        // Use trim to eliminate leading or trailing white space

        String productString = mProductEditText.getText().toString().trim();
        int price = Integer.parseInt(priceInt);
        String quantityString = mQuantityEditText.getText().toString().trim();
        String suppliernameString = mSupplierNameEditText.getText().toString().trim();
        String supplierphoneString = mSupplierPhoneEditText.getText().toString().trim();

        // Create database helper
        MeatDbHelper mDbHelper = new MeatDbHelper(this);

        // Gets the database in write mode
        SQLiteDatabase db = mDbHelper.getWritableDatabase();

        // Create a ContentValues object where column names are the keys,
        // and inventory attributes from the editor are the values.
        ContentValues values = new ContentValues();
        values.put(MeatsContract.MeatEntry.PRODUCT, productString);
        values.put(MeatsContract.MeatEntry.COLUMN_PRICE, priceInt);
        values.put(MeatsContract.MeatEntry.COLUMN_QUANTITY, quantityString);
        values.put(MeatsContract.MeatEntry.COLUMN_SUPPLIER_NAME, suppliernameString);
        values.put(MeatsContract.MeatEntry.COLUMN_SUPPLIER_PHONE, supplierphoneString);

        // Insert a new row for pet in the database, returning the ID of that new row.
        long newRowId = db.insert(MeatsContract.MeatEntry.TABLE_NAME, null, values);


    }
}